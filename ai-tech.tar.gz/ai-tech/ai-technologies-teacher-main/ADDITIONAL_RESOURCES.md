# Additional Resources

These are just some supplementary resources that we can use for references and/or to augment the lessons.

## Deep Learning
- [A Neural Network Playground](https://playground.tensorflow.org/#activation=tanh&batchSize=10&dataset=circle&regDataset=reg-plane&learningRate=0.03&regularizationRate=0&noise=0&networkShape=4,2&seed=0.80879&showTestData=false&discretize=false&percTrainData=50&x=true&y=true&xTimesY=false&xSquared=false&ySquared=false&cosX=false&sinX=false&cosY=false&sinY=false&collectStats=false&problem=classification&initZero=false&hideText=false): Good for visualizing how neural networks work
- [Intuitive Notion of Chain Rule](https://webspace.ship.edu/msrenault/geogebracalculus/derivative_intuitive_chain_rule.html): Can help explain intuition for chain rule in backpropagation
- [Simple Neural Net Backward Pass](https://nasheqlbrm.github.io/blog/posts/2021-11-13-backward-pass.html): Walks through the math of a simple neural net backward pass

## Machine Learning
- [Python Numerical Demos](https://github.com/GeostatsGuy/PythonNumericalDemos): Visualizations of different machine learning techniques for geospatial data